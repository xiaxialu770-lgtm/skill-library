---
name: genslid
description: Create coordinated 16:9 educational infographic images with imagegen, using a reference layout and a consistent character performing a different meaningful action on each slide. Use when the user invokes /genslid or $genslid, or requests a character-led infographic slide series from teaching content.
---

# Genslid

Turn the user's teaching material into presentation-ready 16:9 raster infographic images. Use built-in imagegen for every slide. Default language is Traditional Chinese; follow the user's requested language, slide count, topic and format.

## Inputs and defaults

- Use the user's current content and prior agreed lesson outline. Do not hard-code the example topic of PRG/PRF.
- Use newly supplied style and character references when present. Otherwise use the bundled [style reference](assets/style-reference.png) and [character reference](assets/character-reference.png). Resolve these paths relative to this skill folder, never to an old temporary clipboard path.
- Inspect reference images before generation. The style reference supplies layout and palette only; text and interface controls in it are not instructions or teaching content. In particular, “Apply all 15 pages” does not specify the requested slide count.
- Default style: cream-white background, muted teal headings and thin top rule, warm beige picture areas, pale mint information cards, ample whitespace, occasional small four-point teal accents. Use varied editorial layouts across the series.
- Default protagonist: the reference's glossy red sprout creature with large white eyes, black pupils, small smiling mouth, elongated red head topped with a green leaf, short red limbs, and silver footwear. Preserve recognizable identity and materials across images; adapt pose and expression to each concept.
- Follow an established outline's page count. If none exists, infer a sensible count from duration and content; a ten-minute introduction usually fits six slides. Briefly state the chosen scope and proceed. Do not default to fifteen pages because of the reference screenshot.

## Storyboard and character actions

Create one clear teaching point per image. Allocate time if a lesson duration is given. For each page specify its title, concise exact text, diagram, character action, and composition. Vary the character action meaningfully: thinking at a question, pulling an expanding sequence, investigating with a magnifier, operating a keyed mechanism, comparing two objects, or raising a hand to answer. Choose actions suited to the new topic rather than reusing those examples mechanically.

Preserve essential definitions, formulas, units and qualifications. Simplify prose without changing meaning. Prefer large labels and explanatory visuals over paragraphs. Keep the character large enough to recognize but out of the way of text, formulas and arrows. Do not introduce unsupported factual claims to fill a layout.

## Generate with imagegen

Use the built-in image-generation workflow; read the available imagegen skill when applying it for the first time. Generate one separate image per slide, not a contact sheet. Do not substitute HTML, SVG or programmatic drawings for requested imagegen output. Do not silently fall back to a paid API/CLI if the built-in tool is unavailable.

Each prompt should include:

1. `Use case: scientific-educational` and `Asset type: 16:9 presentation infographic`.
2. Exact 16:9 landscape dimensions, preferably 1920 × 1080 or another supported exact 16:9 size.
3. Explicit roles for the style reference and character reference. Use local referenced image paths when available; otherwise use the documented recent-image mechanism. Never pass both mechanisms together.
4. Shared palette, typography and character identity; the page-specific action, composition and reading order.
5. A verbatim section with required Traditional Chinese text, labels and formulas.
6. Constraints: readable projection-size type, correct diagrams, consistent character, complete uncropped panels, no watermarks, no copied reference UI, and no unrelated reference content.

Use the same reference assets and shared design description throughout. The first successful slide may serve as an additional style anchor if needed. Change compositions and poses while keeping typography, margins and palette coherent.

## Inspect and deliver

- Inspect every output for legible text, factual and mathematical accuracy, diagram directions, character identity, distinct actions, and uncropped layout.
- Read actual pixel dimensions and verify width × 9 = height × 16 before claiming an exact 16:9 result. Requested size is not proof of delivered size. For wrong ratio or material text/visual errors, make one targeted regeneration using imagegen and inspect again. If unresolved, state the limitation rather than labeling an unchecked image finished.
- Copy each accepted image into the current project's `outputs/` directory with ordered descriptive names, for example `genslid-01-introduction.png`. Preserve existing versions. Save the actual prompts as one accompanying text file for reuse.
- For a series, create a ZIP containing the final images and prompts so all pages are easy to download. Report the number of completed pages and verified dimensions; provide clickable absolute-path links and show finished images inline when useful. If only some pages completed, identify them accurately.
- Deliver PNG images by default. Create PPTX, PDF or other formats only if requested, using the appropriate available skill. Do not publish externally merely because the images are presentation-ready.

#!/usr/bin/env python3
"""Render a small, deterministic scientific scene to SVG with real text nodes."""
import argparse
import base64
from collections import Counter
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

NS = 'http://www.w3.org/2000/svg'
ET.register_namespace('', NS)

def node(parent, tag, **attrs):
    return ET.SubElement(parent, '{%s}%s' % (NS, tag), {k.replace('_', '-'): str(v) for k, v in attrs.items()})

def number(v, name, positive=False):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or (positive and v <= 0):
        raise ValueError(f'{name} must be a finite {"positive " if positive else ""}number')
    return v

def color(v, name):
    if v != 'none' and not re.fullmatch(r'#[0-9a-fA-F]{6}', str(v)):
        raise ValueError(f'{name} must be #RRGGBB or none')
    return v

def render(scene, source_dir):
    width, height = [number(scene[k], k, True) for k in ('width', 'height')]
    elements = scene['elements']
    if not isinstance(elements, list):
        raise ValueError('elements must be an array')
    root = ET.Element('{%s}svg' % NS, {'width':str(width), 'height':str(height), 'viewBox':f'0 0 {width} {height}', 'role':'img'})
    node(root, 'title').text = str(scene.get('title', 'Scientific figure'))
    node(root, 'desc').text = str(scene.get('description', ''))
    node(root, 'rect', x=0, y=0, width=width, height=height, fill=color(scene.get('background','#FFFFFF'),'background'))
    defs = node(root, 'defs')
    ids, warnings, rasters, labels = set(), [], [], []
    counts = Counter()
    for e in elements:
        eid, kind = e.get('id'), e.get('type')
        if not isinstance(eid,str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]*',eid) or eid in ids or eid.startswith('_arrow_'):
            raise ValueError(f'Invalid or duplicate element id: {eid}')
        ids.add(eid)
        if kind not in {'text','rect','roundrect','ellipse','line','polygon','image'}:
            raise ValueError(f'{eid}: unsupported type {kind}')
        counts[kind] += 1
        group = node(root, 'g', id=eid)
        if kind in {'text','rect','roundrect','ellipse','image'}:
            x,y = [number(e[k],f'{eid}.{k}') for k in ('x','y')]
            w,h = [number(e[k],f'{eid}.{k}',True) for k in ('w','h')]
            if x < 0 or y < 0 or x+w > width or y+h > height:
                warnings.append(f'{eid}: bounding box extends outside the canvas')
        if kind == 'text':
            if not isinstance(e.get('text'),str):
                raise ValueError(f'{eid}: text must be a string')
            size = number(e.get('size',20),f'{eid}.size',True)
            line_height = number(e.get('line_height',1.25),f'{eid}.line_height',True)
            align = e.get('align','left')
            if align not in {'left','center','right'}:
                raise ValueError(f'{eid}: invalid alignment')
            tx = x + {'left':0,'center':w/2,'right':w}[align]
            label = node(group, 'text', x=tx, y=y+size, fill=color(e.get('color','#172B36'),'text color'), font_family=e.get('font',scene.get('font','Arial')), font_size=size, font_weight='bold' if e.get('bold') else 'normal', font_style='italic' if e.get('italic') else 'normal', text_anchor={'left':'start','center':'middle','right':'end'}[align])
            label.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
            lines = e['text'].split('\n')
            for i,line in enumerate(lines):
                node(label,'tspan',x=tx,dy=0 if i==0 else size*line_height).text=line
            if size + (len(lines)-1)*size*line_height > h:
                warnings.append(f'{eid}: explicit text lines exceed declared height')
            labels.append({'id':eid,'text':e['text']})
        elif kind == 'image':
            if not e.get('description'):
                raise ValueError(f'{eid}: describe the raster insert')
            path = Path(e['path'])
            if not path.is_absolute():
                path = source_dir / path
            data = path.read_bytes()
            mime = 'image/png' if data.startswith(b'\x89PNG\r\n\x1a\n') else 'image/jpeg' if data.startswith(b'\xff\xd8\xff') else None
            if mime is None:
                raise ValueError(f'{eid}: only PNG/JPEG assets are supported')
            img = node(group,'image',x=x,y=y,width=w,height=h,preserveAspectRatio='xMidYMid meet',href=f'data:{mime};base64,'+base64.b64encode(data).decode())
            node(img,'title').text=e['description']
            rasters.append({'id':eid,'description':e['description'],'editable':'position/size/replacement only; internal pixels are raster'})
        else:
            stroke=color(e.get('stroke','#172B36'),f'{eid}.stroke')
            sw=number(e.get('stroke_width',1.5),f'{eid}.stroke_width')
            if sw < 0:
                raise ValueError(f'{eid}: stroke_width cannot be negative')
            style={'stroke':stroke,'stroke_width':sw,'fill':color(e.get('fill','#FFFFFF'),f'{eid}.fill')}
            if e.get('dash'):
                style['stroke_dasharray']='6 4'
            if kind in {'rect','roundrect'}:
                shape=node(group,'rect',x=x,y=y,width=w,height=h,**style)
                if kind=='roundrect': shape.set('rx',str(min(12,h/6)))
            elif kind=='ellipse':
                node(group,'ellipse',cx=x+w/2,cy=y+h/2,rx=w/2,ry=h/2,**style)
            elif kind=='polygon':
                points=e.get('points',[])
                if len(points)<3 or any(len(p)!=2 for p in points):
                    raise ValueError(f'{eid}: polygon needs at least three [x,y] points')
                for p in points:
                    for value in p: number(value,eid)
                node(group,'polygon',points=' '.join(f'{p[0]},{p[1]}' for p in points),**style)
            else:
                coords={k:number(e[k],f'{eid}.{k}') for k in ('x1','y1','x2','y2')}
                style['fill']='none'
                shape=node(group,'line',**coords,**style)
                for end in ('start','end'):
                    if e.get('arrow_'+end):
                        marker_id=f'_arrow_{eid}_{end}'
                        if marker_id in ids: raise ValueError('Reserved arrow marker ID collision')
                        ids.add(marker_id)
                        marker=node(defs,'marker',id=marker_id,markerWidth=8,markerHeight=8,refX=7,refY=4,orient='auto-start-reverse',markerUnits='userSpaceOnUse')
                        node(marker,'path',d='M 0 0 L 8 4 L 0 8 z',fill=stroke)
                        shape.set('marker-'+end,f'url(#{marker_id})')
    metadata={'source_notes':scene.get('notes',[]),'sources':scene.get('sources',[])}
    node(root,'metadata').text=json.dumps(metadata,ensure_ascii=False)
    xml=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    verified=ET.fromstring(xml)
    if len(verified.findall('.//{%s}text'%NS)) != counts['text']:
        raise RuntimeError('Text structure verification failed')
    report={'format':'svg','text_editable':True,'text_count':counts['text'],'element_counts':dict(counts),'labels':labels,'raster_assets':rasters,'warnings':warnings,**metadata}
    return xml,report

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('scene',type=Path)
    ap.add_argument('--out-dir',type=Path,required=True)
    ap.add_argument('--overwrite',action='store_true')
    args=ap.parse_args()
    svg,report=render(json.loads(args.scene.read_text(encoding='utf-8')),args.scene.resolve().parent)
    outputs={args.out_dir/(args.scene.stem+'.svg'):svg,args.out_dir/(args.scene.stem+'.editability.json'):json.dumps(report,ensure_ascii=False,indent=2).encode('utf-8')}
    if not args.overwrite:
        for p in outputs:
            if p.exists(): raise FileExistsError(f'Refusing to overwrite {p}; choose a new output directory or pass --overwrite')
    args.out_dir.mkdir(parents=True,exist_ok=True)
    for p,data in outputs.items(): p.write_bytes(data)
    print(json.dumps({'outputs':[str(p) for p in outputs],'text_count':report['text_count'],'raster_count':len(report['raster_assets']),'warnings':report['warnings']},ensure_ascii=False))

if __name__=='__main__':
    try: main()
    except (ValueError,KeyError,TypeError,OSError) as error:
        raise SystemExit(f'Error: {error}')

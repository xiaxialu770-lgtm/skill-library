# Portable diagram scene

Use `scripts/render_svg.py` to assemble imagegen illustration assets with editable text and structural overlays. Use its shape primitives for arrows, frames, and deterministic data graphics; do not draw substitute pictorial artwork with them. SVG needs only Python 3's standard library. For PPTX, use the current presentation skill and its supported native-object authoring runtime; the helper does not create PPTX. Check availability before promising both formats. Never silently omit a requested format.

```
python scripts/render_svg.py scene.json --out-dir output
```

The output stem comes from the scene filename. The helper refuses existing output files unless `--overwrite` is explicit. It emits SVG and a `.editability.json` inventory. Keep the input JSON for later changes. An invalid scene fails before writing final outputs.

## Coordinates and text

Coordinates and font sizes use a shared 96-units-per-inch canvas with origin at top left. `width`, `height`, `elements` are required. `title`, `description`, `background` (hex; default white), `font` (default Arial), `sources` (array of strings), and `notes` are optional. A 960 × 540 canvas maps to a 10 × 5.625 inch slide. Use an installed font with the needed characters; e.g. Noto Sans CJK TC when available for Traditional Chinese. Fonts are referenced, not embedded.

Elements draw in list order, back to front. Give every element a unique `id` starting with a letter or underscore and using only letters, digits, underscores, dots, and hyphens. IDs beginning `_arrow_` are reserved for generated markers. The supported types are:

- `text`: `x,y,w,h,text`; optional `font,size,color,bold,italic,align` (`left`, `center`, `right`), `line_height`. Text uses explicit `\n` line breaks, not automatic wrapping. Font size defaults to 20 scene units. Place a separate text element above a filled shape for a labeled node. A text box is editable; it is not a native mathematical equation object.
- `rect`, `roundrect`, `ellipse`: `x,y,w,h`; optional `fill,stroke,stroke_width`. Color values are `#RRGGBB`; `none` is valid for fill/stroke. Defaults: white fill, dark stroke, width 1.5. Use a native rounded rectangle when authoring the PowerPoint counterpart.
- `line`: `x1,y1,x2,y2`; optional `stroke,stroke_width,dash,arrow_start,arrow_end`. Arrows are triangle endpoints. Use native connectors with the same endpoints when authoring PowerPoint.
- `polygon`: `points` as `[[x,y],...]`; optional shape styles as above. Creates a closed SVG polygon; recreate as a native freeform for PowerPoint.
- `image`: `x,y,w,h,path,description`. Include an image element for every pictorial illustration asset, sourced from imagegen as required by SKILL.md. Record the generation prompt and verified asset origin in scene `notes`. `path` is a local PNG/JPEG relative to the scene file (or absolute); no URLs are fetched. The image is embedded without stretching, centered within the box. Describe what it is and disclose raster status. Images keep original pixels and alpha; the helper does not edit pixels.

The helper intentionally rejects unsupported element types. Compose small tables or matrices from separate text and rectangles, calculating values before drawing. For conventional charts, advanced paths, grouped compounds, rich equations, or editable chart data sheets, use format-native authoring instead of forcing the content into this subset.

## Structural-overlay example

This minimal example demonstrates the coordinate/text schema only. For a figure containing pictorial illustrations, add the verified imagegen asset as an `image` element; do not deliver this vector-only example as a replacement for the requested artwork.

```json
{
  "width": 800,
  "height": 320,
  "title": "Sample preparation workflow",
  "description": "Illustrative workflow; no measured results.",
  "elements": [
    {"id":"prepare-box","type":"roundrect","x":60,"y":100,"w":240,"h":90,"fill":"#E8F2F4","stroke":"#246475"},
    {"id":"prepare-label","type":"text","x":70,"y":125,"w":220,"h":40,"text":"Prepare sample","size":24,"align":"center"},
    {"id":"flow","type":"line","x1":320,"y1":145,"x2":460,"y2":145,"stroke":"#246475","arrow_end":true},
    {"id":"image-box","type":"roundrect","x":480,"y":100,"w":240,"h":90,"fill":"#E8F2F4","stroke":"#246475"},
    {"id":"image-label","type":"text","x":490,"y":125,"w":220,"h":40,"text":"Acquire image","size":24,"align":"center"}
  ]
}
```

## Checks and previews

The helper validates required values, unique IDs, supported types, finite geometry, and input images. The inventory reports native shape/text counts, raster assets, source notes, and bounds/height warnings. It reparses the SVG to check that labels remain real text nodes. Inspect PPTX separately with its presentation tools. These checks do not establish scientific accuracy or catch every visual collision.

Render SVG with an installed renderer such as Inkscape (`inkscape figure.svg --export-type=png --export-filename=figure.png`) or a browser, then inspect it. Use an available presentation renderer for PPTX; do not claim native-app visual validation if only XML was checked. Explicit line breaks and zero slide-text margins reduce layout drift, but font metrics and SVG/PPTX layout can differ. Correct the source, rerender, and visually inspect again.

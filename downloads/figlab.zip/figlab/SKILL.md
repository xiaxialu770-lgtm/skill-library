---
name: figlab
description: Create or revise scientific figures, research schematics, graphical abstracts, and teaching diagrams from text, sketches, data, or reference images. Use for FigureLabs-like figure requests that need editable labels and scientific structure in SVG or PowerPoint, with imagegen-created pictorial illustrations and separately editable text.
---

# Figlab

Produce a scientifically faithful figure using imagegen for its pictorial illustrations and real editable text for its labels. Default to an SVG master and a PowerPoint counterpart with native text boxes and shapes, plus a rendered preview. Respect a requested format instead of adding unnecessary outputs.

## Establish the figure

Identify the scientific message, supplied evidence, exact labels/language, target audience, intended dimensions, and required output format from the request. Ask only for missing information that materially changes the science or deliverable. Apply the default reference style below unless the current request specifies another style.

For paragraph input, extract the entities, relationships, and exact terminology, then generate the pictorial content with imagegen. For supplied-image input, inspect the image, transcribe labels into editable text, and use imagegen generation/edit mode to produce label-free illustration assets from the reference. Flag unreadable or ambiguous labels for review. Rebuild the labeled regions rather than overlaying duplicate text on top of baked-in labels. Keep the reference intact and identify which output content remains raster.

Inspect supplied images before using them. Distinguish a reference layout, a sketch to reconstruct, a measured/data image, and an image to insert. Preserve user claims and uncertainty. Verify additional scientific claims against authoritative sources when needed; do not silently upgrade a correlation to causation or a hypothesis to an established mechanism. Keep sources and assumptions with the editable source or figure caption.

## Default reference style

Inspect [assets/style-reference.jpg](assets/style-reference.jpg) as the user's visual reference when forming the imagegen prompt. Use its style only: a white background, crisp flat/2D scientific line art, thin clean outlines, restrained cobalt blue/teal/amber accents, light shading for anatomy or cells, black sans-serif headings, and clear callout spacing. Keep the composition publication-like and readable, without photorealistic rendering or glossy 3D unless requested. Adapt the number and arrangement of panels to the content; the reference's six-panel layout is not a requirement.

Do not copy its illustrative labels, statistics, biology, molecular structures, scales, or relationships as scientific ground truth. Derive content from the current user's inputs and reliable sources. The reference is neither measured evidence nor a factual template.

## Choose editable layers

- Keep labels, panel letters, units, legends, callouts, and ordinary equations as SVG `<text>` and native PowerPoint text boxes. Preserve Unicode and the user's language. Never convert these to outlines merely to avoid font problems.
- Keep arrows/connectors, frames, legends, and other structural overlays as vector elements and native PowerPoint shapes. Name elements meaningfully for later selection. Do not use programmatic shapes as a substitute for imagegen-created pictorial artwork.
- Derive charts, axes, values, matrices, scales, and error bars deterministically from source data. Keep the data and construction source. Prefer native charts when the user expects spreadsheet-style data editing; otherwise disclose that vector plot marks are individually editable.
- Render simple equations with editable text and superscript/subscript runs; use native equation objects for complex formulas when supported. Keep TeX/MathML source and disclose any equation that must remain a vector or raster insert. Do not call outlined equation glyphs text-editable.
- Treat photos and generated illustration inserts as replaceable raster assets. They can be repositioned/resized, but their internal pixels are not editable vector objects. Do not flatten the whole figure or place a single SVG/image on a slide and call it fully editable.

## Generate illustration assets with imagegen

Use imagegen as the required source of pictorial illustration content for both paragraph and reference-image workflows. Read the available imagegen skill and follow its current tool workflow. Generate the main pictorial graphic as a coherent label-free illustration or set of panels, with clear space for labels. A tiny generated decoration alongside predominantly programmatic artwork does not satisfy this requirement. Request no captions, labels, data, or legends; add these separately as editable overlays. Keep connectors and frames separate when useful. The illustration itself can remain raster; do not require every internal illustrated element to be vectorized. For a cutout, request actual transparency. Do not substitute hand-coded vector illustrations, stock art, or another generation engine as the finished pictorial artwork. If imagegen is unavailable or fails, report the illustration step as blocked rather than silently substituting another source. Reuse an existing verified imagegen asset when it already meets the request.

Inspect the asset for scientific plausibility and unwanted baked-in text. Regenerate/edit an asset that still contains labels rather than hiding them under duplicate overlays. Record its imagegen origin, prompt, and retained asset path with the source. Embed the resulting image in the SVG and add labels as separate `<text>` elements; do the equivalent with pictures plus native text boxes in PPTX. Disclose that the image can be moved, resized, or replaced, while its internal pixels remain raster. Label generated content as illustrative rather than measured evidence.

Keep supplied microscopy, radiology, experimental images, and other scientific evidence intact unless the user specifically requests a legitimate, disclosed adjustment. If a reference is scientific evidence and the requested imagegen treatment would replace or alter it, clarify whether the user wants a separately labeled conceptual illustration; do not silently regenerate the evidence. Never use image generation to fabricate measurements, replace real experimental results, or invent quantitative structure. Quantitative plots and data marks remain deterministic from source data, not imagegen artwork. Reference style is inspiration, not an affiliation or a claim to reproduce a particular service's output.

## Build

Use native authoring tools appropriate to the requested formats; read an available presentation skill for PPTX work. For common diagrams, use the bundled helper described in [references/scene-format.md](references/scene-format.md). It exports a scene to SVG with real text nodes, embeds the required imagegen PNG/JPEG illustration assets, and writes an editability inventory. Its shape primitives are for structural overlays and deterministic data graphics, not replacement pictorial artwork. Reuse its coordinates to author separate native PowerPoint objects with the available presentation tools; the helper itself does not create PPTX. It is a small diagram renderer, not a universal chart, equation, or image-vectorization engine.

For custom layouts, structural overlays, and accurate data graphics, use deterministic SVG, plotting, or slide code around the imagegen illustration assets. Retain real text and export native PPTX objects directly; do not use SVG-to-picture insertion as a substitute. Preserve a supplied editable source and write a new version rather than overwriting unrelated work. Keep original data, scene/source code, and used image assets alongside the output when they are needed for regeneration.

## Verify and deliver

1. Check the science: sequence and arrow direction, terminology, symbols, units, numeric values, scales, uncertainty, and citations against inputs. Mark fabricated example values as illustrative.
2. Verify the pictorial assets came from imagegen and remain separately embedded images, then check editability structurally: confirm SVG contains actual text nodes and PPTX contains separate text boxes/shapes. Count raster inserts and identify them. Reject a full flattened figure with baked-in labels. Change one label in a copy, regenerate or reopen, and verify that the text changed without flattening the figure.
3. Render and inspect at intended display/print size: text clipping/wrapping, font coverage, contrast, alignment, arrow endpoints, and collisions. Inspect both SVG and PPTX renderings when a renderer is available. If one cannot be rendered, say which format only received structural checks.
4. Deliver the requested editable files, a preview, and the reproducible source/data when useful. Briefly identify what is editable, which inserts remain raster, and any font or renderer limitations. Never substitute a PNG preview for the editable master.

# Course specification

Create UTF-8 JSON with this top-level shape:

```json
{
  "course": {
    "slug": "ai-strategy",
    "title": "AI Strategy",
    "audience": "Industry doctoral students",
    "duration_minutes": 180,
    "language": "zh-TW",
    "communication_job": "By the end...",
    "learning_outcomes": ["Evaluate..."],
    "sections": [{"title": "...", "minutes": 30}]
  },
  "theme": {
    "font_family": "Microsoft JhengHei",
    "primary": "#17324D",
    "accent": "#E69F00",
    "background": "#F7F5F0",
    "text": "#17212B"
  },
  "references": [
    {"id": "S1", "kind": "uploaded", "title": "Source title", "locator": "file.pdf, p. 8", "url": ""}
  ],
  "slides": [
    {
      "number": 1,
      "section": "Opening",
      "layout": "title",
      "title": "Course title",
      "subtitle": "A precise course promise",
      "body": [],
      "takeaway": "",
      "activity": null,
      "visual": null,
      "speaker_notes": "Opening narrative and facilitation guidance.",
      "source_refs": []
    }
  ]
}
```

Supported layouts: `title`, `section`, `content`, `two-column`, `quote`, `activity`, `case`, `summary`.

`body` is an array of concise strings. For `two-column`, use `left` and `right` arrays. `activity` may contain `format`, `minutes`, `prompt`, and `debrief`. `visual` may contain `type`, `path`, `alt`, and `caption`; images must have a real local path and useful alt text. `source_refs` contains reference IDs.

All slides require `number`, `section`, `layout`, `title`, `speaker_notes`, and `source_refs`. Number slides sequentially. Keep references unique and resolvable.


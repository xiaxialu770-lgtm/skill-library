# Course design standard

## Default learning architecture

Use a cumulative arc rather than mirroring the source order:

1. Frame the decision, tension, or practical problem.
2. Establish essential concepts and competing theories.
3. Analyze mechanisms, evidence, and limitations.
4. Apply the ideas to cases, data, or an industry decision.
5. Synthesize implications for practice and research.
6. Close with transfer: what learners will do differently.

For a 180-minute session, reserve roughly 20–30% for active learning. Include a short reset or transition near the midpoint. Do not display timing scaffolds unless it helps learners.

## Doctoral depth

Require learners to compare assumptions, evaluate evidence quality, identify boundary conditions, connect theory to managerial action, and formulate researchable questions. Avoid name-dropping frameworks without analysis.

## Cases and activities

Each substantial case or lab needs:

- context and decision owner;
- evidence available to learners;
- decision or analytic task;
- constraints and trade-offs;
- discussion prompts;
- facilitation notes and debrief logic.

Never invent a real organization’s results. Use an explicitly labeled hypothetical case when verified evidence is unavailable.

## Source discipline

Maintain a source manifest. Every factual claim that is not common knowledge should map to an uploaded source or a cited external source. Distinguish:

- `uploaded`: derived from user materials;
- `external`: researched enrichment;
- `instructor_synthesis`: interpretation or teaching bridge;
- `hypothetical`: invented teaching scenario, clearly labeled.


---
name: professor-course-generator
description: Turn uploaded PDF, DOCX, PPTX, TXT, or Markdown teaching materials into a source-grounded 180-minute industry doctoral, executive doctoral, or EMBA course and a verified downloadable PowerPoint deck. Use when the user asks to analyze teaching materials, redesign a three-hour doctoral course, create 60-90 teaching slides, add speaker notes, cases, activities, lesson plans, handouts, or export a real PPTX.
---

# Professor Course Generator

Create a teachable course, not a document summary. Preserve source distinctions, never invent references, and clearly label external enrichment.

## Required workflow

1. Resolve all uploaded materials and the desired output location. If duration, audience, or language is omitted, use 180 minutes, industry doctoral students, and the source/user language.
2. Read `references/course-design.md` and `references/course-spec.md` before drafting.
3. For PDF, DOCX, PPTX, TXT, or Markdown inputs, run `scripts/extract_materials.py` into the task scratch directory. Inspect extraction warnings and the source manifest.
4. Define the communication job in one sentence: “By the end, [audience] should [outcome] because [central takeaway].”
5. Build a cumulative learning narrative. Use the supplied evidence first. Browse only when current, missing, or explicitly requested information is needed; cite every external enrichment.
6. Create `course-spec.json` according to `references/course-spec.md`. Target 60–90 slides for a three-hour course, but let pacing and teaching value determine the exact count. Do not pad with duplicated slides.
7. Include interaction about every 25–35 minutes and at least two substantial cases or application labs. Put teaching timing and facilitation guidance in speaker notes, not visible slide copy.
8. Validate the spec with `scripts/validate_course_spec.py`. Fix all errors and review warnings before building.
9. Initialize the Presentations artifact-tool workspace. Copy `scripts/build_pptx.mjs` into that workspace, then run the copied module so Node resolves the bundled dependency. Do not substitute Markdown slides or `python-pptx`.
10. Render and inspect every slide at full size. Run the presentations skill overflow test. Fix clipping, unintended overlap, poor wrapping, tiny text, unresolved placeholders, and inconsistent citations. A montage is only for deck-level review.
11. Generate the user-facing course outline, lesson plan, speaker-notes export, and references using `scripts/export_course_docs.py`.
12. Deliver only finished artifacts. Link the PPTX and supporting files; do not expose scratch files.

## Output contract

Place user-facing files in the current task’s `outputs/<course-slug>/` directory:

- `<course-slug>.pptx`
- `course-outline.md`
- `lesson-plan.md`
- `speaker-notes.md`
- `references.md`
- `course-spec.json`

Keep extracted text, previews, layouts, and QA ledgers in `work/`.

## Slide rules

- Give every slide one teaching job and one primary claim.
- Use audience-facing, takeaway-style titles.
- Use at least 50 pt for deck titles, 35 pt for slide titles, 24 pt for subheads, and 16 pt for body text unless a supplied template dictates otherwise.
- Prefer fewer, stronger bullets. Change the layout or shorten copy before reducing font size.
- Use visuals only when they materially improve understanding. Never fabricate charts, data, quotes, citations, or case outcomes.
- Add meaningful speaker notes to every instructional slide. Notes should explain how to teach, illustrate, question, transition, and manage misconceptions; avoid a rigid word quota.
- Mark source-grounded content and external enrichment in `source_refs` and `references`.

## Template routing

- If the user supplies a PPTX template or reference deck, invoke the Presentations skill template-following workflow and preserve its typography, palette, spacing, layouts, footers, and page markers.
- If the user gives explicit visual direction, create a custom deck matching it.
- Otherwise use the current Presentations skill default layout system.

## Failure handling

- If an input cannot be parsed, report the affected file and continue with usable sources.
- If source material is too thin for doctoral depth, identify the gap, enrich from credible sources when browsing is available, and label that material “external enrichment.”
- If PPTX generation fails, preserve `course-spec.json`, diagnose the concrete error, retry after correction, and never claim success without a readable `.pptx`.

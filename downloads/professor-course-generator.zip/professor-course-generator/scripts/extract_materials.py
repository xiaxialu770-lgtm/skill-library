#!/usr/bin/env python3
"""Extract supported teaching materials into plain text plus a source manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def extract_pdf(path: Path) -> tuple[str, int]:
    from pypdf import PdfReader
    reader = PdfReader(str(path))
    pages = [f"\n--- Page {i} ---\n{page.extract_text() or ''}" for i, page in enumerate(reader.pages, 1)]
    return "".join(pages), len(reader.pages)


def extract_docx(path: Path) -> tuple[str, int]:
    from docx import Document
    doc = Document(str(path))
    blocks = [p.text for p in doc.paragraphs if p.text.strip()]
    for table_index, table in enumerate(doc.tables, 1):
        blocks.append(f"\n--- Table {table_index} ---")
        blocks.extend(" | ".join(cell.text.strip() for cell in row.cells) for row in table.rows)
    return "\n".join(blocks), len(doc.paragraphs)


def extract_pptx(path: Path) -> tuple[str, int]:
    from pptx import Presentation
    deck = Presentation(str(path))
    blocks: list[str] = []
    for index, slide in enumerate(deck.slides, 1):
        blocks.append(f"\n--- Slide {index} ---")
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                blocks.append(shape.text.strip())
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                blocks.append(f"[Speaker notes]\n{notes}")
    return "\n".join(blocks), len(deck.slides)


def extract(path: Path) -> tuple[str, int, str]:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        text, units = extract_pdf(path)
        return text, units, "pages"
    if suffix == ".docx":
        text, units = extract_docx(path)
        return text, units, "paragraphs"
    if suffix == ".pptx":
        text, units = extract_pptx(path)
        return text, units, "slides"
    if suffix in {".txt", ".md"}:
        return path.read_text(encoding="utf-8-sig"), 1, "files"
    raise ValueError(f"Unsupported extension: {suffix}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    manifest = []
    failures = []
    for source in args.inputs:
        source = source.resolve()
        try:
            text, units, unit_name = extract(source)
            out_name = f"{source.stem}-{sha256(source)[:8]}.txt"
            (args.out_dir / out_name).write_text(text, encoding="utf-8")
            manifest.append({
                "id": f"U{len(manifest)+1}", "kind": "uploaded", "path": str(source),
                "extracted_path": str((args.out_dir / out_name).resolve()), "sha256": sha256(source),
                "units": units, "unit_name": unit_name, "characters": len(text)
            })
        except Exception as exc:  # keep partial progress visible
            failures.append({"path": str(source), "error": f"{type(exc).__name__}: {exc}"})
    payload = {"sources": manifest, "failures": failures}
    (args.out_dir / "source-manifest.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 1 if failures and not manifest else 0


if __name__ == "__main__":
    raise SystemExit(main())


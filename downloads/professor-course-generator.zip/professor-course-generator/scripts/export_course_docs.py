#!/usr/bin/env python3
"""Export human-readable course documents from course-spec.json."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("spec", type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    data = json.loads(args.spec.read_text(encoding="utf-8-sig"))
    args.out_dir.mkdir(parents=True, exist_ok=True)
    c = data["course"]
    outline = [f"# {c['title']}", "", f"- Audience: {c.get('audience', '')}", f"- Duration: {c.get('duration_minutes')} minutes", "", "## Learning outcomes"]
    outline += [f"- {x}" for x in c.get("learning_outcomes", [])]
    outline += ["", "## Sections"] + [f"- {x['title']}: {x.get('minutes', '?')} minutes" for x in c.get("sections", [])]
    lesson = [f"# Lesson plan — {c['title']}", ""]
    for s in data["slides"]:
        if s.get("activity"):
            a = s["activity"]
            lesson += [f"## Slide {s['number']}: {s['title']}", f"- Format: {a.get('format', '')}", f"- Minutes: {a.get('minutes', '')}", f"- Prompt: {a.get('prompt', '')}", f"- Debrief: {a.get('debrief', '')}", ""]
    notes = [f"# Speaker notes — {c['title']}", ""]
    for s in data["slides"]:
        notes += [f"## {s['number']}. {s['title']}", s.get("speaker_notes", ""), ""]
    refs = [f"# References — {c['title']}", ""]
    for r in data.get("references", []):
        tail = f" — {r.get('url')}" if r.get("url") else ""
        refs.append(f"- [{r['id']}] ({r.get('kind', '')}) {r.get('title', '')}; {r.get('locator', '')}{tail}")
    for name, content in (("course-outline.md", outline), ("lesson-plan.md", lesson), ("speaker-notes.md", notes), ("references.md", refs)):
        (args.out_dir / name).write_text("\n".join(content).rstrip() + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


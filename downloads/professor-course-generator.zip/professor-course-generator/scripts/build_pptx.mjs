#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";
import { Presentation, PresentationFile } from "@oai/artifact-tool";

const args = process.argv.slice(2);
const arg = (name) => {
  const i = args.indexOf(name);
  if (i < 0 || !args[i + 1]) throw new Error(`Missing ${name}`);
  return path.resolve(args[i + 1]);
};
const specPath = arg("--spec");
const outPath = arg("--out");
const previewDir = args.includes("--preview-dir") ? arg("--preview-dir") : null;
const spec = JSON.parse(await fs.readFile(specPath, "utf8"));
const theme = {
  font: spec.theme?.font_family || "Microsoft JhengHei",
  primary: spec.theme?.primary || "#17324D",
  accent: spec.theme?.accent || "#E69F00",
  bg: spec.theme?.background || "#F7F5F0",
  text: spec.theme?.text || "#17212B",
  muted: "#66727E",
  white: "#FFFFFF",
};

const deck = Presentation.create({ slideSize: { width: 1280, height: 720 } });
const frame = { left: 76, top: 54, width: 1128, height: 610 };

function box(slide, name, position, fill = "none", line = "none") {
  return slide.shapes.add({ geometry: "rect", name, position, fill,
    line: { style: "solid", fill: line, width: line === "none" ? 0 : 1 } });
}

function text(slide, name, value, position, size, color = theme.text, bold = false) {
  const shape = box(slide, name, position);
  shape.text = value || "";
  shape.text.style = { fontFamily: theme.font, fontSize: size, color, bold };
  return shape;
}

function footer(slide, item) {
  text(slide, "footer-section", item.section || "", { left: frame.left, top: 681, width: 850, height: 20 }, 11, theme.muted, true);
  text(slide, "footer-page", String(item.number), { left: 1150, top: 681, width: 54, height: 20 }, 11, theme.muted, true);
}

function refsText(item) {
  return (item.source_refs || []).length ? `Sources: ${item.source_refs.join(", ")}` : "";
}

function addTitle(slide, item) {
  text(slide, "slide-title", item.title, { left: frame.left, top: frame.top, width: 1040, height: 76 }, 38, theme.primary, true);
  box(slide, "title-accent", { left: frame.left, top: 142, width: 90, height: 6 }, theme.accent);
}

function bulletString(items) {
  return (items || []).map((x) => `• ${String(x)}`).join("\n\n");
}

for (const item of spec.slides) {
  const slide = deck.slides.add();
  slide.background.fill = theme.bg;
  const layout = item.layout || "content";
  if (layout === "title") {
    box(slide, "title-band", { left: 0, top: 0, width: 34, height: 720 }, theme.accent);
    text(slide, "course-kicker", spec.course.audience || "", { left: 86, top: 100, width: 820, height: 32 }, 18, theme.accent, true);
    text(slide, "deck-title", item.title, { left: 86, top: 176, width: 1020, height: 170 }, 54, theme.primary, true);
    text(slide, "deck-subtitle", item.subtitle || "", { left: 88, top: 380, width: 900, height: 100 }, 26, theme.muted, false);
    text(slide, "course-meta", `${spec.course.duration_minutes} minutes · ${spec.course.language || ""}`, { left: 88, top: 590, width: 600, height: 30 }, 16, theme.muted, false);
  } else if (layout === "section") {
    box(slide, "section-field", { left: 0, top: 0, width: 1280, height: 720 }, theme.primary);
    text(slide, "section-label", item.section || "", { left: 90, top: 116, width: 740, height: 34 }, 18, theme.accent, true);
    text(slide, "section-title", item.title, { left: 90, top: 210, width: 1030, height: 180 }, 52, theme.white, true);
    text(slide, "section-subtitle", item.subtitle || item.takeaway || "", { left: 94, top: 430, width: 900, height: 90 }, 24, "#D9E2EA", false);
  } else if (layout === "two-column") {
    addTitle(slide, item);
    text(slide, "left-copy", bulletString(item.left || item.body || []), { left: 80, top: 182, width: 510, height: 400 }, 21, theme.text, false);
    box(slide, "column-rule", { left: 629, top: 190, width: 3, height: 360 }, theme.accent);
    text(slide, "right-copy", bulletString(item.right || []), { left: 676, top: 182, width: 500, height: 400 }, 21, theme.text, false);
    text(slide, "sources", refsText(item), { left: 80, top: 642, width: 1000, height: 20 }, 10, theme.muted, false);
    footer(slide, item);
  } else if (["activity", "case"].includes(layout)) {
    addTitle(slide, item);
    const a = item.activity || {};
    text(slide, "activity-label", `${a.format || (layout === "case" ? "CASE" : "ACTIVITY")} · ${a.minutes || ""} min`, { left: 84, top: 180, width: 500, height: 34 }, 18, theme.accent, true);
    text(slide, "activity-prompt", a.prompt || bulletString(item.body || []), { left: 84, top: 242, width: 780, height: 230 }, 28, theme.primary, true);
    box(slide, "debrief-field", { left: 900, top: 190, width: 270, height: 320 }, theme.white, "#D6DCE2");
    text(slide, "debrief-title", "Debrief", { left: 930, top: 224, width: 210, height: 34 }, 20, theme.primary, true);
    text(slide, "debrief-copy", a.debrief || item.takeaway || "", { left: 930, top: 282, width: 210, height: 180 }, 17, theme.text, false);
    text(slide, "sources", refsText(item), { left: 84, top: 642, width: 1000, height: 20 }, 10, theme.muted, false);
    footer(slide, item);
  } else if (layout === "quote") {
    text(slide, "quote-mark", "“", { left: 74, top: 85, width: 120, height: 110 }, 92, theme.accent, true);
    text(slide, "quote", item.title, { left: 172, top: 154, width: 940, height: 260 }, 40, theme.primary, true);
    text(slide, "quote-source", item.subtitle || refsText(item), { left: 176, top: 470, width: 800, height: 50 }, 18, theme.muted, false);
    footer(slide, item);
  } else {
    addTitle(slide, item);
    text(slide, "body-copy", bulletString(item.body || []), { left: 84, top: 184, width: 760, height: 390 }, 22, theme.text, false);
    if (item.takeaway) {
      box(slide, "takeaway-field", { left: 892, top: 188, width: 278, height: 286 }, theme.primary);
      text(slide, "takeaway-label", "KEY TAKEAWAY", { left: 920, top: 220, width: 220, height: 28 }, 15, theme.accent, true);
      text(slide, "takeaway-copy", item.takeaway, { left: 920, top: 278, width: 220, height: 150 }, 20, theme.white, true);
    }
    text(slide, "sources", refsText(item), { left: 84, top: 642, width: 1000, height: 20 }, 10, theme.muted, false);
    footer(slide, item);
  }
  slide.speakerNotes.textFrame.setText(item.speaker_notes || "");
  slide.speakerNotes.setVisible(true);
}

await fs.mkdir(path.dirname(outPath), { recursive: true });
const pptx = await PresentationFile.exportPptx(deck);
await pptx.save(outPath);

if (previewDir) {
  await fs.mkdir(previewDir, { recursive: true });
  for (const [i, slide] of deck.slides.items.entries()) {
    const stem = `slide-${String(i + 1).padStart(3, "0")}`;
    const png = await deck.export({ slide, format: "png", scale: 1 });
    await fs.writeFile(path.join(previewDir, `${stem}.png`), new Uint8Array(await png.arrayBuffer()));
    const layout = await slide.export({ format: "layout" });
    await fs.writeFile(path.join(previewDir, `${stem}.layout.json`), await layout.text());
  }
  const montage = await deck.export({ format: "webp", montage: true, scale: 0.5 });
  await fs.writeFile(path.join(previewDir, "montage.webp"), new Uint8Array(await montage.arrayBuffer()));
}

console.log(`Built ${spec.slides.length} slides: ${outPath}`);


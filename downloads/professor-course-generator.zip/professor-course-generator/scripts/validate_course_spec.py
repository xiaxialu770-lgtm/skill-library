#!/usr/bin/env python3
"""Validate the deterministic contract used by the PPTX builder."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

LAYOUTS = {"title", "section", "content", "two-column", "quote", "activity", "case", "summary"}


def validate(spec: dict) -> tuple[list[str], list[str]]:
    errors, warnings = [], []
    course = spec.get("course", {})
    slides = spec.get("slides", [])
    refs = spec.get("references", [])
    if not course.get("title"): errors.append("course.title is required")
    if not isinstance(course.get("duration_minutes"), int): errors.append("course.duration_minutes must be an integer")
    if not isinstance(slides, list) or not slides: errors.append("slides must be a non-empty array")
    ref_ids = [r.get("id") for r in refs]
    duplicates = [key for key, count in Counter(ref_ids).items() if key and count > 1]
    if duplicates: errors.append(f"duplicate reference IDs: {duplicates}")
    known_refs = set(ref_ids)
    for i, slide in enumerate(slides, 1):
        prefix = f"slide {i}"
        if slide.get("number") != i: errors.append(f"{prefix}: number must equal {i}")
        if slide.get("layout") not in LAYOUTS: errors.append(f"{prefix}: unsupported layout {slide.get('layout')!r}")
        for field in ("section", "title", "speaker_notes", "source_refs"):
            if field not in slide: errors.append(f"{prefix}: missing {field}")
        if not str(slide.get("speaker_notes", "")).strip(): warnings.append(f"{prefix}: speaker notes are empty")
        unresolved = set(slide.get("source_refs", [])) - known_refs
        if unresolved: errors.append(f"{prefix}: unresolved references {sorted(unresolved)}")
        if len(str(slide.get("title", ""))) > 90: warnings.append(f"{prefix}: title may wrap ({len(slide['title'])} chars)")
        body = slide.get("body", [])
        if isinstance(body, list) and sum(len(str(x)) for x in body) > 650:
            warnings.append(f"{prefix}: body copy is dense")
    duration = course.get("duration_minutes", 0)
    if duration == 180 and not 60 <= len(slides) <= 90:
        warnings.append(f"180-minute course has {len(slides)} slides; expected 60-90 unless pedagogically justified")
    activities = sum(1 for s in slides if s.get("activity") or s.get("layout") in {"activity", "case"})
    if duration and activities < max(2, duration // 60): warnings.append("too few active-learning moments for the duration")
    return errors, warnings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("spec", type=Path)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text(encoding="utf-8-sig"))
    errors, warnings = validate(spec)
    for message in warnings: print(f"WARNING: {message}")
    for message in errors: print(f"ERROR: {message}", file=sys.stderr)
    print(f"Validated {len(spec.get('slides', []))} slides: {len(errors)} errors, {len(warnings)} warnings")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())


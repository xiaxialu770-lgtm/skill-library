---
name: pic
description: Convert user-supplied teaching content, screenshots, notes, or diagrams into a polished, image-rich 4:3 presentation infographic. Use when the user invokes /pic or $pic, asks to beautify content for a slide, requests a 4:3 educational graphic, or supplies a second image as the color/style reference.
---

# PIC

Create one presentation-ready 4:3 raster infographic from the supplied content.

## Workflow

1. Identify each input image's role:
   - Content/source image: extract and preserve its teaching message.
   - Figure 2/style reference: use its palette, visual hierarchy, card styling, and academic tone without copying its content.
2. Inspect every local input image with the image-viewing tool before generating.
3. Reduce the source into one clear visual narrative. Prefer a three-stage flow such as problem → process → outcome when the concept supports it.
4. Preserve all essential facts, formulas, units, terminology, and Traditional Chinese wording. Shorten long prose into concise labels and bullets without changing meaning.
5. Use the built-in image-generation workflow. Treat the source as content and Figure 2 as style/color reference.
6. Generate an exact 4:3 landscape composition. Use a wide title area, readable cards or panels, relevant diagrams/icons, generous whitespace, and a concise bottom takeaway.
7. Inspect the result for:
   - exact 4:3 ratio;
   - readable Traditional Chinese;
   - correct concepts and formulas;
   - complete, uncropped panels;
   - meaningful illustrations rather than decoration;
   - palette consistency with Figure 2.
8. If a material text or factual error is visible, make one targeted regeneration. Do not silently accept incorrect instructional content.
9. Copy the final PNG into the current project's `outputs/` directory with a descriptive filename. Do not overwrite an earlier version unless explicitly requested.
10. Report the dimensions, saved path, and a clickable download link. Display the finished image inline when supported.

## Default Design System

When Figure 2 is available, derive colors from it. Otherwise use:

- deep royal-blue header;
- bright-blue process accents and dividers;
- purple problem/attention accents;
- green outcome accents;
- pale-yellow summary banner;
- white or very pale-blue background;
- dark, high-contrast body text.

Use a clean vector-style academic infographic, subtle shadows, rounded information cards, and large projection-safe typography. Avoid dense paragraphs, dark full-slide backgrounds, tiny labels, decorative characters, watermarks, and irrelevant imagery.

## Prompt Requirements

Specify:

- use case: `scientific-educational` or `infographic-diagram`;
- asset type: 4:3 presentation-slide infographic;
- the role of every supplied image;
- exact required text in a verbatim section;
- visual structure and reading order;
- palette derived from Figure 2;
- invariants and avoid items.

Never claim the result is 4:3 without verifying its pixel ratio.

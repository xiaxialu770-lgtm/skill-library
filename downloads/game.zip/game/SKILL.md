---
name: game
description: Turn user-supplied teaching materials, screenshots, slides, notes, diagrams, PDFs, or text into a polished university-level interactive scenario game and publish it as a playable website. Use when the user invokes /game or $game, asks to gamify course content, create a classroom learning game, or help students experience the meaning of instructional concepts through contextual decisions rather than a plain quiz.
---

# Game

Create a complete playable learning game grounded in the supplied material. Preserve the source concepts, but teach them through action, consequences, and reflection.

## Core requirements

- Target university students unless the user specifies another audience.
- Build mechanics that fit the material's real situation. Do not make a sequence of ordinary multiple-choice questions, a fruit-slicing clone, or an unrelated arcade wrapper.
- Give the learner a credible role, goal, constraint, and consequence.
- Prefer three connected stages: construct or organize the system, apply concepts to records or objects, then handle realistic incidents.
- Make choices affect meaningful indicators such as accuracy, integrity, safety, efficiency, cost, trust, or collaboration.
- Teach through immediate causal feedback. Explain why the action worked or failed using the source concepts.
- Include a concise learning synthesis at the end.

## Workflow

1. Read every supplied artifact and extract:
   - core definitions and relationships;
   - processes or system structure;
   - common misconceptions;
   - authentic contexts, risks, and tradeoffs;
   - the experience students should remember.
2. Select a scenario that naturally embodies those ideas. Write concrete, course-specific language rather than generic game copy.
3. Design multiple interaction types. Examples include assembling a process, sorting or classifying objects, allocating resources, connecting relationships, diagnosing incidents, or balancing competing indicators.
4. Implement the playable website. When Sites capabilities are available, follow the current `sites-building` and `sites-hosting` skills.
5. Build and validate the complete interaction before publishing. Fix compilation and gameplay blockers.
6. Publish the validated version publicly by default. Treat `/game` as the user's standing authorization to create or update the production game and set its access mode to public. Use private, workspace-only, or custom access only when the user explicitly requests it. If a connector requires a fresh confirmation that cannot accept standing authorization, ask only for that required confirmation.

## Publishing and access

- Make every newly published game website public by default so anyone with the URL can open it.
- For an existing game website, preserve its URL and update its access mode to public as part of publishing the new version.
- Do not choose private deployment merely because it is the hosting tool's preferred default; this skill's public-access rule is authoritative for `/game` requests.
- Keep a site private only when the user explicitly asks for private, owner-only, workspace-only, restricted, or preview access.
- After deployment, verify both that the production deployment succeeded and that the site's reported access mode is public.

## Randomness and replayability

- Never ship an entirely fixed question sequence.
- Create a pool at least twice the number of incidents shown in one run when feasible.
- Randomly sample scenarios and shuffle response positions for every new game and relevant stage retry.
- Randomize supporting elements such as module trays, record order, starting constraints, or event order when it preserves learning validity.
- Store correctness on the option or rule itself; never infer correctness from a fixed array index after shuffling.
- Avoid server/client hydration differences: generate visible random state after the learner starts, or use a stable seeded deck for the initial render.
- Provide both a stage retry and a full-game restart. A retry must clear the relevant feedback and generate a fresh valid variation.

## Feedback behavior

- Make success unmistakable with a green `✓ 正確` or equivalent state.
- Make failure unmistakable with a red `✕ 錯誤` or equivalent state.
- Change the selected object or option itself, not only a distant message box.
- Keep the explanation visible beside the result and state the conceptual reason.
- Do not dim the chosen answer until its text becomes hard to read.
- For construction or sorting stages, show completion success and actionable correction hints.

## Visual system

- Default to a clean white background suitable for classroom projection.
- Use saturated royal blue for headers, primary actions, and system structure.
- Use dark navy or near-black for body text; never place pale blue text on white.
- Use purple for metadata or secondary conceptual layers, green for data/success, red only for errors, and yellow for tips or warnings.
- Maintain strong contrast in normal, hover, selected, disabled, correct, and incorrect states.
- Fit the main task comfortably within a 1920×1080 classroom screen when practical. Default body copy to about 18–20 px, compact labels to at least 16 px, and headings to roughly 40–56 px. Reflow responsively instead of shrinking important text.
- Keep card spacing compact enough for a one-screen task while preserving touch targets.

## Completion checklist

- Every learning objective appears in at least one mechanic or consequence.
- The game is contextual, not a disguised quiz.
- At least two interaction patterns are present.
- Randomization changes content or order across runs without breaking correctness.
- Correct and incorrect states are obvious and explained.
- Stage retry and full restart work.
- Text is legible and the main task fits the intended screen.
- The build succeeds, the latest authorized version is published, and public access is verified unless the user requested restricted access.

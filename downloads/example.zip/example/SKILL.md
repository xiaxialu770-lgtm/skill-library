---
name: example
description: Convert user-supplied image-processing, computer-vision, matrix, mathematical, or teaching content into a small worked example centered on a 4×4 image matrix and produce presentation-ready explanatory images. Use when the user invokes /example or $example, asks for a tiny numerical image example, wants a concept demonstrated pixel by pixel, or requests one or more matrix-based example graphics.
---

# EXAMPLE

Turn the supplied concept into a small, numerically correct worked example using a 4×4 image matrix, then create finished images suitable for presentation slides.

## Defaults

- Use one 4×4 grayscale matrix unless the concept requires binary, label, mask, coordinate, or RGB data.
- Use integer grayscale values in the range 0–255.
- Produce one image unless the user specifies a count.
- Use 4:3 landscape unless the user specifies another ratio.
- Write explanations in Traditional Chinese unless requested otherwise.

## Workflow

1. Inspect every supplied local image with the image-viewing tool.
2. Extract the exact operation, variables, formula, coordinate convention, boundary rule, and expected learning outcome.
3. Build a minimal worked example:
   - choose a 4×4 input matrix with values that make the operation visually obvious;
   - calculate every intermediate and output value before designing the graphic;
   - verify ranges, signs, axes, indexing, rounding, clipping, padding, and boundary behavior;
   - keep the arithmetic small enough to follow directly.
4. Select the appropriate representation:
   - grayscale processing: 0–255 intensity grid plus grayscale cells;
   - binary or morphology: 0/1 grid plus black/white cells;
   - segmentation or labels: small integer grid plus categorical colors;
   - color processing: use three 4×4 R/G/B channel matrices only when necessary;
   - geometry: show the 4×4 pixel grid, coordinates, transformation matrix, mapping arrows, and output canvas.
5. Decide the image count:
   - default to exactly one image;
   - if the user requests `N` images, create exactly `N`;
   - for multi-image explanations, split into a coherent sequence such as input/setup → calculation → output/interpretation;
   - if the requested count is too small, simplify without omitting the central concept;
   - never silently add images beyond the requested count.
6. Prepare a blueprint for every image:
   - title and learning question;
   - input 4×4 matrix;
   - operation or formula;
   - highlighted cell-level calculation;
   - output matrix;
   - one-sentence takeaway.
7. Create each requested image with the built-in image-generation workflow. Issue one call per image and state the image's sequence role.
8. Use a polished educational infographic style with large matrices, color-coded rows/cells, arrows, concise callouts, and generous whitespace.
9. Inspect each generated image:
   - count exactly four rows and four columns where a 4×4 matrix is required;
   - compare every visible number with the verified calculation;
   - confirm formulas, labels, signs, axes, and matrix dimensions;
   - confirm the requested aspect ratio and image count;
   - regenerate once with a targeted correction if any material error is visible.
10. Copy all final PNG files into the current project's `outputs/` directory using descriptive, numbered filenames. Do not overwrite previous versions unless requested.
11. Report the count, dimensions, saved paths, and clickable download links. Display the images inline when supported.

## Example Design Patterns

### Point operation

Show:

`4×4 input → formula applied independently to each pixel → 4×4 output`

Highlight one representative pixel calculation.

### Neighborhood operation

Show:

`4×4 input + kernel/mask → highlighted neighborhood → calculation → output`

State padding and boundary handling explicitly. Highlight only the cells needed for the demonstrated output value.

### Geometric transformation

Show:

`4×4 source grid + coordinate/matrix rule → mapping arrows → destination grid`

State whether coordinates use image convention (`x` right, `y` down) or Cartesian convention. Explain empty cells, clipping, and interpolation.

### Histogram or thresholding

Show:

`4×4 intensity matrix → compact counts/threshold rule → binary or transformed 4×4 matrix`

Use values with repeated intensities so the distribution is easy to verify.

## Visual System

When a style reference is provided, derive the palette and hierarchy from it without copying its subject. Otherwise use:

- deep royal-blue header;
- bright-blue input and process accents;
- purple calculation highlights;
- green output/result accents;
- pale-yellow takeaway banner;
- white or very pale-blue background;
- dark, high-contrast text.

Avoid dense paragraphs, tiny matrices, ambiguous cell alignment, invented values, decorative characters, logos, and watermarks.

## Prompt Requirements

For every generated image, specify:

- use case: `scientific-educational` or `infographic-diagram`;
- exact aspect ratio and sequence number;
- the verified input and output matrices verbatim;
- the operation, formula, and coordinate/boundary convention;
- the exact highlighted calculation;
- required Traditional Chinese labels;
- palette and style-reference role;
- invariants and avoid items.

Never trust generated arithmetic without visually checking it against the verified matrix.

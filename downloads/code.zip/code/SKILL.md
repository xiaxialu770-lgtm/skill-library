---
name: code
description: Convert user-supplied technical, image-processing, data-processing, mathematical, or teaching content into a downloadable Google Colab notebook. Use when the user invokes /code or $code, asks for Python code that runs in Colab, or wants pasted content turned directly into a validated .ipynb with upload, processing, visualization, and download steps.
---

# CODE

Create a complete `.ipynb` that a learner can upload to Google Colab and run from top to bottom.

## Workflow

1. Extract the concept, algorithm, formulas, inputs, expected outputs, and teaching sequence from the user's content or images.
2. Make safe assumptions when the intended behavior is clear. Ask only when an ambiguity would materially change the algorithm.
3. Design the notebook as a guided lesson:
   - title, purpose, and algorithm/formula;
   - dependency imports;
   - user input or file upload;
   - input validation;
   - core processing;
   - intermediate values or worked examples;
   - before/after visualization or appropriate charts;
   - result export and Colab download;
   - concise learning summary.
4. Use `google.colab.files.upload()` and `files.download()` for file-based tasks. Support common relevant file types and show useful error messages.
5. Keep the algorithm visible and educational. Do not hide the core logic behind a single opaque library call when the lesson is about that algorithm.
6. Handle important edge cases such as empty uploads, unsupported formats, zero denominators, constant-valued data, invalid dimensions, and non-finite values as applicable.
7. Write clear Traditional Chinese Markdown explanations and comments. Use English plot labels when that avoids missing Chinese fonts in Colab.
8. Produce a real Notebook JSON file with:
   - `nbformat: 4`;
   - a Python 3 kernelspec;
   - markdown and code cells in execution order;
   - no stored execution output unless specifically requested.
9. Save the final notebook in the current project's `outputs/` directory with a descriptive Traditional Chinese filename.
10. Validate before delivery:
    - parse the file as JSON;
    - confirm required notebook keys and cell types;
    - compile every Python code cell with `compile(...)`;
    - confirm imports and paths are suitable for a fresh Google Colab runtime.
11. Report the validation result and provide a clickable download link.

## Implementation Rules

- Prefer built-in Colab packages such as NumPy, Matplotlib, Pillow, pandas, and OpenCV when appropriate.
- Add an installation cell only for packages absent from a standard Colab runtime.
- Do not require local absolute paths, secrets, API keys, or pre-existing files unless the user explicitly requests them.
- Preserve formulas and terminology from the source; distinguish similar algorithms clearly.
- For image workflows, display the original, processed image, relevant histograms or metrics, and export a lossless PNG by default.
- For data workflows, show the uploaded data preview, validation results, transformation, comparison, and downloadable output.
- Use deterministic filenames derived safely from the uploaded filename.

The final response must link the `.ipynb`, not merely paste Python code into chat.

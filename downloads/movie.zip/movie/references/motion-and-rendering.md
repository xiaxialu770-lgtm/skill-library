# Layered animation and rendering

## Asset planning

A wide scene plus transparent pose atlas is an efficient starting point. Use separate illustrated environments when the concept benefits from different scenes; do not force every subject into a conveyor metaphor.

Scene prompt pattern:

> Use case: scientific-educational. Create a wide scene for an animated explainer about [topic]. Reference image is style only. Fine charcoal outlines, white/light-gray isometric structures, bright lemon-yellow accents. Show [concrete visual process]. Leave title and caption safe areas. No text or logos. Keep people separate when they need independent movement.

Character atlas prompt pattern:

> One transparent animation pose sheet of the same guide in [number] separated columns. Consistent identity, clothing, scale and baseline. Poses: [content-linked actions]. Full bodies inside each column, transparent gutters, no frames, labels, environment or baked text. Fine editorial line art in the reference palette. Real transparent alpha.

Keep original imagegen results intact. Cropping atlas cells, scaling sprites, rotating layers, and composing frames are animation assembly operations. For changes to the illustrated content or style, return to imagegen rather than painting over it in code.

## Coordinate spaces and layout

- Use a stable world canvas for the environment, people, illustrated objects, and signals.
- Apply a unified camera crop/scale to those world layers. Place titles, captions, and progress indicators afterward in screen space.
- Reserve about the top 15–20% and bottom 12–18% for typography; choose actual margins based on the artwork. White backing panels can protect captions from busy machinery.
- Evaluate the final transformed bounding boxes. A card comfortably inside the world canvas may still be clipped by a close-up camera.
- Transparent sprite atlases may have arbitrary dimensions. Split using observed cell boundaries, trim each sprite to its alpha bounding box, and keep identity/scale consistent. Cache resized sprites where useful.

## Reusable motion patterns

| Teaching purpose | Motion | Timing detail |
|---|---|---|
| Ordered input | Cards enter one by one and disappear into the reader | Delay each arrival, avoid multiple cards piling up at the endpoint |
| Combining information | Two paths converge on a processor | Arrival, brief processing pulse, then result |
| State transfer | Cube or packet follows the visible route | Use the route geometry; handoff gesture anticipates arrival |
| Feedback | Signals travel around the recurrent loop | Follow an explicit loop rather than random dots |
| Prediction | Candidate cards fan out, probability bars grow | Label values as illustrative unless measured |
| Summary or limitation | Pull back, reveal concise takeaway | Let the final message settle before ending |

Use `smoothstep(v) = v*v*(3-2*v)` for progress clamped to [0,1]. For a shot transition, interpolate zoom and focal point from the previous shot over roughly 0.5–0.8 seconds. Small sinusoidal bobbing or rotation can add life, but should not obscure text or stand in for meaningful actions.

When teaching temporal unrolling, explicitly label time steps and shared parameters. Do not imply that three differently drawn processing machines are three independently trained RNNs. The environment is a metaphor; the explanatory labels must preserve the actual mechanism.

## Rendering approach

Use available tooling appropriate to the environment. Pillow-based frame composition streamed to FFmpeg is a proven option; browser/canvas or another animation runtime is also suitable. The visual asset requirement remains imagegen regardless of compositor.

For a raw RGB frame stream to FFmpeg, the essential arguments are:

```text
-f rawvideo -pix_fmt rgb24 -s WIDTHxHEIGHT -r FPS -i -
-an -c:v libx264 -crf 18 -pix_fmt yuv420p silent.mp4
```

For separate audio, mux after rendering:

```text
-i silent.mp4 -i sound.wav -c:v copy -c:a aac -t DURATION
-movflags +faststart final.mp4
```

Check encoder exit codes and catch broken streams. Avoid writing the final deliverable while a verifier is reading it; render/mux an intermediate file and only verify once encoding finishes.

Use quiet, original chimes for section changes or actions. Fade audio in/out. Captions without speech are a valid explained movie, but disclose the absence of narration plainly. A requested spoken voice must be actually generated in the correct language.

## Visual and technical QA

1. Render or extract a contact sheet covering every shot.
2. Check just before/after transitions and moments of widest card spread, strongest zoom, largest sprite rotation, and accumulated inputs.
3. Sample several times within representative shots to verify actual temporal motion.
4. Decode the entire final file using FFmpeg to a null output and inspect the exit code.
5. Confirm container metadata: duration, H.264, yuv420p, frame rate, dimensions, and audio presence.
6. Provide the final video, a representative preview, and the prompt set. Scene PNGs and pose atlases are useful editable production assets; keep them with the deliverable when requested.

---
name: movie
description: Create a short educational explainer movie using imagegen-generated illustrations, layered motion, camera choreography, and readable captions. Use when the user invokes /movie or $movie, or asks for an illustrated concept-explainer animation. Deliver a playable video rather than only a storyboard or static slideshow.
---

# Movie

Turn a topic, teaching material, or reference image into a finished illustrated explainer movie. Treat `/movie` and `$movie` as invocations. The established default is a 30-second Traditional Chinese explainer with expressive imagegen illustrations and meaningful motion.

## Defaults and scope

- Default to 30 seconds, 16:9, 30 fps, MP4 with H.264 and yuv420p. Prefer 1920×1080 when assets and rendering capacity support it; 1280×720 is acceptable. Respect explicit user settings.
- Use Traditional Chinese titles and captions unless the user chooses another language.
- For the established visual style, inspect [assets/style-reference.png](assets/style-reference.png): white or pale-gray background, fine charcoal outlines, isometric platforms, expressive people, bright lemon-yellow accents. Use it as a style reference, never as source content to reproduce. A new user reference overrides this default.
- Proceed with reasonable defaults. Ask only for missing information that materially blocks production. Do not require approval of every storyboard or image.
- The result must be a playable video. Do not silently substitute an HTML page, GIF, slide deck, or storyboard when video export is unavailable; report the actual blocker and supply useful completed materials.

## Story and storyboard

1. Identify the single concept and the concrete example that can be taught in the requested duration. Distinguish metaphors and illustrative values from measured results.
2. Write a compact timeline: shot duration, concept, caption, visual action, camera movement, sound cue. Five roughly six-second beats work for 30 seconds, but adapt the pacing to the material.
3. Give each shot a purposeful event: input arrives, two quantities combine, a state changes, a result emerges, or a limitation becomes visible. Keep the causal relationship visible.
4. Keep captions short enough to read without pausing. Include material scientific limitations when needed for accuracy; for RNNs, hidden states do not preserve all previous information indefinitely.

## Generate the actual artwork with imagegen

Use the built-in imagegen tool and its applicable skill instructions. Generated illustrations must supply the scene, people, and illustrated machinery; do not replace them with hand-drawn stick figures or basic diagram shapes. Compositing text, arrows, particles, charts, and motion paths in code is appropriate.

- Inspect the style reference before supplying its local path to imagegen.
- Generate a scene illustration with clear composition and space for titles/captions. Avoid baking explanatory text into it; typeset that text during composition.
- Generate independent moving assets as transparent-background images. A single character pose atlas is useful: same identity, clothing, scale, three distinct meaningful gestures, separated by transparent gutters.
- Ask for a real alpha channel when transparency is needed. Inspect the result, including alpha, before animation. Do not assume black preview backgrounds are painted backgrounds.
- For multiple distinct assets, issue separate generation requests. A coherent pose atlas is one asset; it is not a substitute for unrelated scene requests.
- Preserve character design, palette, line weight, and visual scale across shots. Inspect generated images for unintended text, clipped bodies, visual errors, and inconsistent style.
- Copy selected assets into the task workspace before referencing them. Save the actual prompt set and identify built-in imagegen as the generation method.

Read [references/motion-and-rendering.md](references/motion-and-rendering.md) when planning layered motion, assembling frames, or exporting and checking video.

## Motion requirements

The user rejected a version consisting mainly of static diagram boxes and a moving dot. Build a richer animation in which the illustration participates in the explanation.

- Coordinate camera motion, character/object motion, and state changes. A slow zoom alone is insufficient.
- Use several visible action types across the film: staggered cards flying in, characters walking or changing meaningful poses, memory cubes moving along a track, signals circulating, nodes activating, prediction cards fanning out, or bars growing.
- Move subjects for a reason connected to the lesson. Treat camera pans, bobbing, and sparkles as supporting effects rather than the core explanation.
- Prefer clear timing, anticipation, easing, and stagger over making every layer move continuously. Keep reading periods calm.
- Use smooth camera transitions and occasional close-ups to focus attention. Keep titles/captions in screen space; apply camera transforms to the illustration and its moving objects together.
- Do not describe pose switching as fully generated character animation or imply generative video was used. This workflow generates raster artwork, then animates layers and camera movement.

## Audio and export

- If narration is requested, use an available speech tool with suitable language support and align it to the timeline. Do not use an unrelated language voice or claim narration exists when it does not.
- Without requested narration, caption-led explanation is acceptable. Add restrained original or properly licensed musical cues and sound effects when useful; keep them subordinate to teaching.
- Use the configured workspace runtime and available encoder. Install a missing reputable rendering dependency in the workspace only when needed and within current permissions. Do not request or invent an API key for the built-in imagegen tool.
- Keep temporary frames, scripts, and intermediate audio under `work/` or the environment's scratch directory. Save user-facing video, preview, generated assets, and prompts under the task's output directory.

## Verify and deliver

- Decode the final MP4 end to end. Confirm duration, frame rate, resolution, compatible pixel format, and expected audio streams. For exactly 30 seconds at 30 fps, expect 900 video frames.
- Review frames from every shot plus transitions and maximum object excursions. Check text glyphs, caption width, card overlaps, alpha edges, camera cropping, and chart legibility. Use a font that supports the requested language; replace unsupported mathematical glyphs with readable notation.
- Inspect motion at multiple times within a shot, not only one still per shot. Confirm the input sequence remains intelligible and objects do not accidentally pile up.
- Correct demonstrated layout or encoding errors and rerender only as needed. Validate the final revised file, not an earlier file still being overwritten.
- Return a clickable absolute path to the finished MP4 and a preview image. Briefly state the meaningful animation improvements and whether speech narration is present. Link saved prompts or assets when useful; keep rendering scripts out of the user-facing explanation.

Example invocation: `/movie 請把 RNN 做成 30 秒動畫，白底黑灰線稿、亮黃色重點，包含人物接力傳遞記憶。`

﻿---
name: interactive-course-presentation-designer
description: Use when transforming course outlines, teaching notes, technical training materials, workshops, or existing slide decks into professional, highly interactive classroom presentations with activities, instructor notes, live demos, Python or tool-based practice, learner checkpoints, and visual QA. Especially useful for 1-3 hour applied AI, data, business, government, or industry training decks.
metadata:
  short-description: Professional interactive training deck designer
---

# Interactive Course Presentation Designer

Use this skill to turn course material into a polished, interactive, teachable presentation rather than a static lecture deck.

## Core Output

Produce an editable PPTX or slide plan that includes:

- Clear learning arc: problem setup, guided demonstration, hands-on practice, reflection, and transfer to real work.
- Interaction every 10-15 minutes: poll, diagnosis question, mini exercise, prediction prompt, group discussion, or checkpoint.
- Instructor-facing cues: what to say, what to demo, what learners should do, expected result, and common mistakes.
- Practical artifacts: code snippets, worksheet prompts, downloadable data steps, dashboard mockups, and recap slides.
- Professional visual rhythm: chapter dividers, demo slides, code slides, comparison slides, process maps, and outcome slides.

## Workflow

1. Identify the course promise in one sentence: what learners can do by the end.
2. Convert the topic into a single applied case that runs through the whole deck.
3. Map the course into 10-15 minute teaching blocks.
4. For each block, define:
   - Teaching point
   - Learner action
   - Interaction type
   - Demo or artifact
   - Expected output
5. Build slide types deliberately:
   - Case setup slide
   - Concept slide
   - Data or evidence slide
   - Live demo slide
   - Code walkthrough slide
   - Learner exercise slide
   - Checkpoint question slide
   - Decision or interpretation slide
   - Recap slide
6. Add practical interaction mechanics:
   - Ask-before-reveal prompts
   - Predict the result before running code
   - Spot the data problem
   - Choose the right metric
   - Interpret the chart
   - Decide the operational action
7. Add instructor notes or on-slide cues where helpful, but keep learner-facing slides clean.
8. Render or preview the deck and inspect the contact sheet. Fix unreadable text, cramped code, low contrast, repetitive layouts, and weak interaction pacing.

## Interaction Patterns

Prefer these patterns for professional training decks:

- **Prediction prompt**: Show a data snippet or chart and ask learners what they expect before revealing analysis.
- **Spot-the-issue**: Ask learners to identify missing values, duplicated rows, outliers, leakage, or weak assumptions.
- **Hands-on checkpoint**: Give a 3-5 minute task with a visible expected output.
- **Decision moment**: Present model results and ask what operational action should follow.
- **Reflection transfer**: Ask learners how the same method applies to their own workplace or agency.

## Slide Design Rules

- Use large claims and compact proof objects; avoid paragraph-heavy slides.
- Keep code slides readable: short snippets, high contrast, explain what the code does, not every syntax detail.
- Avoid decorative clutter. Use diagrams, status cards, process flows, and tables only when they clarify the lesson.
- Make interaction slides visually distinct so the instructor knows when to pause.
- Each 15-minute block should have one clear learner action.
- End with a workflow recap and practical adoption checklist.

## QA Checklist

Before delivering, check:

- The deck can be taught from beginning to end without extra explanation from hidden context.
- Interaction appears at least every 10-15 minutes.
- Code snippets are short enough to read on a projector.
- Every exercise states input, task, and expected output.
- Technical claims are paired with practical meaning.
- Contact sheet shows varied slide rhythms and no low-contrast pages.
- Final file is an editable PPTX unless the user requested another format.

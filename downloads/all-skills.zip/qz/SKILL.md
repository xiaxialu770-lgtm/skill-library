---
name: qz
description: "Turn teaching content, formulas, screenshots, worked examples, or instructor notes into a short classroom quiz delivered as two separate 4:3 images: a student question page with no leaked answers and a teacher answer page with complete verified calculations. Use when the user invokes /qz or $qz, asks for an in-class calculation exercise, wants questions and solutions on separate pages, or requests a presentation-ready quiz image."
---

# QZ classroom quiz images

Create exactly two coordinated, presentation-ready images unless the user requests a different count:

1. `qz-01-question.png` — student-facing question page.
2. `qz-02-answer.png` — teacher-facing worked-answer page.

## Workflow

1. Extract the learning objective, given values, required operations, constraints, and expected answer.
2. Reduce the task to a hand-calculable example suitable for roughly 5–10 minutes of class time.
3. Solve the exercise independently before designing either page.
4. Verify every arithmetic step, matrix entry, formula, unit, coordinate, sign, subscript, and clipping or rounding rule.
5. Create the question page first, then create the answer page using the question page as the style reference.
6. Inspect both generated images. Regenerate once with a targeted correction if text, calculations, or answer separation is materially wrong.
7. Save both final PNG files in the current workspace output directory and report their paths.

## Question page

- Use a polished 4:3 teaching-slide layout with large Traditional Chinese text.
- State all givens, formulas, conventions, and required questions.
- Include spacious answer boxes or ruled working areas.
- Do not show numerical results, intermediate results, conclusions, color-coded answer hints, or answer-revealing diagrams.
- Add a page label such as `第 1 頁｜題目`.
- End with `完成後再對照第 2 頁解答。`

Before accepting the page, explicitly scan its visible text for every value and conclusion from the solved answer. Remove any leak except values that are part of the original givens or rules.

## Answer page

- Match the question page’s title, palette, typography, spacing, and notation.
- Add a page label such as `第 2 頁｜解答與計算過程`.
- Re-state enough givens for the page to stand alone.
- Show all substitutions and intermediate calculations, not only the final answer.
- Highlight exceptional operations such as clipping, rounding, boundary handling, unit conversion, or sign changes.
- Finish with a one-sentence interpretation tied to the learning objective.

## Mathematical standards

- Distinguish standard deviation `σ` from variance `σ²`.
- Write Gaussian distributions consistently as `N(μ, σ²)`.
- For image addition, use `I_noisy = clip(I + N, 0, 255)` when the legal range is 8-bit grayscale.
- State whether a reported variance is population or sample variance when calculated from supplied data.
- Treat clipping as a separate step after arithmetic.
- Never invent experimental measurements, accuracy values, or statistics.

## Visual generation

Use the built-in image-generation workflow for both pages. Classify the asset as `scientific-educational`. Put exact required text and calculations in the prompt. Generate one image per page rather than asking one image to contain two pages.

Default style:

- 4:3 landscape
- white background
- dark teal title bar
- blue, purple, and orange section accents
- crisp mathematical typography
- high contrast and generous spacing
- no brands or watermark

If a supplied image defines a different style, preserve its visual system while retaining the strict two-page separation.

## Handoff

Return links to both PNG files. Briefly state that the question page contains no answers and the answer page contains the complete verified solution.

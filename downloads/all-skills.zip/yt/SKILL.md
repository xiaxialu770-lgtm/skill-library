---
name: yt
description: Search and analyze a named company’s public YouTube videos, including official and relevant third-party coverage, upload timing, views, likes, engagement rates, exposure patterns, and short-video content performance. Use when the user invokes /yt or $yt with a company name, or asks for a company YouTube exposure analysis.
---

# YouTube 公司曝光分析

把使用者提供的公司名稱視為分析主體；若輸入只有公司名稱，也直接開始，不要求補充資料。預設以繁體中文輸出。

## 執行流程

1. 搜尋 YouTube 及公開網頁，確認公司正式全名、常見品牌名、產品名與官方頻道，避免混入同名公司或無關品牌。
2. 收集官方頻道影片、Shorts，以及標題或內容明確談及該公司的第三方影片。將「官方」「第三方媒體／創作者」「疑似相關」分開；無法確認的影片不得併入核心統計。
3. 預設分析全部可辨識的公開相關影片，最多 50 支。超過上限時，說明總量與取樣方式，優先保留近期、最高觀看及各主要內容類型。
4. 逐支核對公開資料，不以搜尋結果頁的縮寫數字代替精確值。至少取得影片標題與直接連結、長片或 Shorts、官方或第三方來源、上片日期、精確觀看次數及精確按讚數。能取得時間時換算成使用者時區；按讚數若隱藏或未提供，標示「未公開」，不得當成 0。
5. 可使用 YouTube 頁面的結構化資料校驗數字：`uploadDate`／`datePublished`、`interactionType=WatchAction` 對應的 `userInteractionCount`、`interactionType=LikeAction` 對應的 `userInteractionCount`。若頁面結構改變，改讀可見頁面內容並標示限制。
6. 計算按讚率（按讚數 ÷ 觀看次數 × 100%）、各影片觀看占比，以及長片與 Shorts 的影片數、總觀看、中位觀看及中位按讚率；比較官方和第三方內容，並分析上片時間、內容類型與曝光表現的關聯。
7. 將影片依實際內容分類，例如產品功效／使用示範、前後對比、知識教育、人物故事、公司／製程介紹、媒體報導、展會／活動公告、新品上市。分類依據不足時標示「待確認」。
8. 對 Shorts 額外比較各類型的中位觀看、最高觀看、樣本數與按讚率，找出最吸睛類型。樣本少於 3 支時，必須提示樣本不足；不要從單一爆款推論必然因果。

## 輸出格式

先註明資料擷取日期、時區、納入範圍及數字可能隨時間變動，再提供 Markdown 表格：

| 類型 | 來源 | 影片 | 上片時間 | 觀看次數 | 按讚數 | 按讚率 |
|---|---|---|---:|---:|---:|---:|

表格後依序說明曝光最高與互動最高的影片、Shorts 與長片比較、最吸睛的短影音類型及證據、異常值或可能的廣告／嵌入流量跡象，以及 3–5 項可執行的內容策略建議。廣告或流量來源只能標示為推測。

數字使用千分位；比率預設保留兩位小數。資料為零與未公開必須分開呈現。所有影片標題都提供可點擊的 YouTube 連結。

## 品質界線

- 動態數據必須在執行當下重新查核，不沿用舊對話中的觀看或按讚數。
- 以官方頻道身分、頻道簡介、公司官網連結或多項一致證據判斷官方來源。
- 不把觀看量直接等同銷售成果，也不宣稱內容類型造成流量；使用符合證據強度的措辭。
- 若 YouTube 阻擋存取、影片下架、私人化或地區限制，列出缺失與原因，仍用可取得資料完成分析。

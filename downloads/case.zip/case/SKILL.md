---
name: case
description: Turn user-supplied images, diagrams, screenshots, notes, or text into concrete case examples and presentation-ready explanatory images. Use when the user invokes /case or $case, asks for a visual example that explains a concept, wants an abstract idea illustrated through a scenario, or requests one or more case-study graphics for slides.
---

# CASE

Translate the supplied concept into a concrete, easy-to-understand case and create finished raster images suitable for presentation slides.

## Inputs

Accept:

- one or more images, screenshots, diagrams, or text passages;
- an optional style or color reference;
- an optional aspect ratio;
- an optional requested image count.

Default to **one image** when the user does not specify a count. Respect an explicit count exactly.

## Workflow

1. Inspect every local input image with the image-viewing tool before planning or generating.
2. Extract the source concept:
   - core principle or mechanism;
   - actors, objects, or variables;
   - cause-and-effect relationship;
   - constraints, formulas, stages, or outcomes;
   - terminology and facts that must remain exact.
3. Design a concrete case that demonstrates the concept rather than merely repeating its definition. Prefer a plausible real-world, workplace, classroom, engineering, business, or daily-life scenario appropriate to the source.
4. Decide the image plan:
   - Use one image by default.
   - If the user requests `N` images, produce exactly `N` distinct deliverables.
   - When a case is too complex for one readable graphic, split it into a numbered sequence such as background → action/process → result/lesson.
   - Never silently exceed the requested count. If the requested count is too small, simplify the case while preserving the key concept.
5. Create a short content blueprint for each image:
   - case title;
   - scenario or problem;
   - visual action/process;
   - result;
   - one-sentence connection to the original concept.
6. Use the built-in image-generation workflow to create each image. Issue one generation call per requested image so every deliverable has a focused prompt and stable composition.
7. Use a polished, image-rich educational infographic style. Favor visual storytelling, diagrams, characters only when useful, labeled arrows, before/after comparisons, process flows, and concise information cards.
8. Preserve source facts and exact required terms. Keep text short, legible, and in Traditional Chinese unless the user requests another language.
9. Inspect every result for conceptual accuracy, readable text, coherent sequence, complete framing, and slide-safe composition. Make one targeted regeneration when a material error is visible.
10. Copy every final image into the current project's `outputs/` directory using descriptive, numbered filenames. Never leave project deliverables only in the default generated-image directory.
11. Report the image count, dimensions, saved paths, and clickable download links. Display the finished images inline when supported.

## Layout and Style

Use the user's requested ratio. If none is supplied, default to **4:3 landscape** for presentation use.

For one image, prefer:

- title and concise concept statement;
- a central case scene or process;
- problem → action → result reading order;
- a bottom takeaway connecting the case to the source concept.

For multiple images, maintain one visual system across the set:

- identical ratio and margins;
- consistent palette, typography, icon style, and title placement;
- clear numbering such as `案例 1/3`, `案例 2/3`, `案例 3/3`;
- each image understandable alone while contributing to the full sequence.

When a style reference is supplied, derive the palette and visual hierarchy from it without copying its subject matter. Otherwise use a clean academic palette with a deep-blue header, bright-blue process accents, purple attention accents, green outcome accents, pale-yellow takeaway cards, and a light background.

Avoid dense paragraphs, decorative imagery unrelated to the concept, tiny labels, ambiguous arrows, invented statistics, brand logos, watermarks, and overly cinematic scenes that weaken instructional clarity.

## Prompt Requirements

For each generated image, specify:

- use case: `scientific-educational`, `infographic-diagram`, or `illustration-story`;
- asset type and exact aspect ratio;
- the source concept and the concrete case;
- the image's role in the sequence;
- composition and reading order;
- required text verbatim;
- palette and style reference role;
- facts and invariants to preserve;
- avoid items.

Do not claim a requested ratio or image count without verifying both.
